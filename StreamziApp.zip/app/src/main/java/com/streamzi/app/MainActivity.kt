package com.streamzi.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController
import org.mozilla.geckoview.AllowOrDeny
import java.lang.reflect.InvocationHandler
import java.lang.reflect.ParameterizedType
import java.lang.reflect.Proxy
import kotlin.math.abs

class MainActivity : Activity() {

    companion object {
        const val HOME = "https://streamzi.netlify.app/"

        @Volatile
        private var runtime: GeckoRuntime? = null

        fun getRuntime(ctx: Context): GeckoRuntime =
            runtime ?: synchronized(this) {
                runtime ?: GeckoRuntime.create(
                    ctx.applicationContext,
                    GeckoRuntimeSettings.Builder().consoleOutput(false).build()
                ).also { runtime = it }
            }
    }

    private lateinit var geckoView: GeckoView
    private lateinit var session: GeckoSession
    private lateinit var fab: TextView
    private lateinit var rt: GeckoRuntime
    private var canGoBack = false
    private var inFullScreen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        geckoView = findViewById(R.id.gecko)
        fab = findViewById(R.id.menu_fab)
        rt = getRuntime(this)

        setupExtensionPrompt()
        setupFab()

        session = GeckoSession()
        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                setFullScreen(fullScreen)
            }
        }
        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                this@MainActivity.canGoBack = canGoBack
            }

            // Block pop-up windows / ad tabs
            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? = null
        }
        session.open(rt)
        geckoView.setSession(session)
        session.loadUri(HOME)
    }

    // ---------- Back / full screen ----------

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            inFullScreen -> session.exitFullScreen()
            canGoBack -> session.goBack()
            else -> super.onBackPressed()
        }
    }

    private fun setFullScreen(on: Boolean) {
        inFullScreen = on
        fab.visibility = if (on) View.GONE else View.VISIBLE
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (on) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (Build.VERSION.SDK_INT >= 28) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                window.attributes = lp
            }
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // ---------- Floating menu button (draggable) ----------

    private fun setupFab() {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        fab.setOnTouchListener(object : View.OnTouchListener {
            var dX = 0f
            var dY = 0f
            var sx = 0f
            var sy = 0f
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        dX = v.x - e.rawX
                        dY = v.y - e.rawY
                        sx = e.rawX
                        sy = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (abs(e.rawX - sx) > slop || abs(e.rawY - sy) > slop) moved = true
                        if (moved) {
                            val p = v.parent as View
                            v.x = (e.rawX + dX).coerceIn(0f, (p.width - v.width).toFloat())
                            v.y = (e.rawY + dY).coerceIn(0f, (p.height - v.height).toFloat())
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) showMenu()
                }
                return true
            }
        })
    }

    private fun showMenu() {
        val items = arrayOf("Reload", "Add extension (link)", "Installed extensions", "Home")
        AlertDialog.Builder(this)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> session.reload()
                    1 -> showInstallDialog()
                    2 -> showExtensions()
                    3 -> session.loadUri(HOME)
                }
            }
            .show()
    }

    // ---------- Extensions ----------

    // The prompt API changed between GeckoView versions, so it is implemented through a
    // dynamic proxy that adapts to whichever signature the library has.
    private fun setupExtensionPrompt() {
        val handler = InvocationHandler { proxy, method, args ->
            when (method.name) {
                "hashCode" -> System.identityHashCode(proxy)
                "equals" -> proxy === args?.getOrNull(0)
                "toString" -> "ExtensionPrompt"
                "onInstallPrompt", "onInstallPromptRequest" -> {
                    val ext = args[0] as WebExtension
                    val perms = args.drop(1)
                        .filterIsInstance<Array<*>>()
                        .flatMap { arr -> arr.filterIsInstance<String>() }
                        .distinct()
                    val wantsResponseObject = (method.genericReturnType as? ParameterizedType)
                        ?.actualTypeArguments?.firstOrNull()?.typeName
                        ?.contains("PermissionPromptResponse") == true
                    val result = GeckoResult<Any>()
                    val name = ext.metaData?.name ?: "this extension"
                    val msg = if (perms.isEmpty()) "No special permissions requested."
                    else "It can access:\n\u2022 " + perms.joinToString("\n\u2022 ")
                    runOnUiThread {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("Add $name?")
                            .setMessage(msg)
                            .setPositiveButton("Add") { _, _ ->
                                result.complete(buildAnswer(wantsResponseObject, true))
                            }
                            .setNegativeButton("Cancel") { _, _ ->
                                result.complete(buildAnswer(wantsResponseObject, false))
                            }
                            .setOnCancelListener {
                                result.complete(buildAnswer(wantsResponseObject, false))
                            }
                            .show()
                    }
                    result
                }
                else -> null
            }
        }
        val delegate = Proxy.newProxyInstance(
            WebExtensionController.PromptDelegate::class.java.classLoader,
            arrayOf(WebExtensionController.PromptDelegate::class.java),
            handler
        ) as WebExtensionController.PromptDelegate
        rt.webExtensionController.promptDelegate = delegate
    }

    private fun buildAnswer(responseObject: Boolean, allow: Boolean): Any? {
        if (!responseObject) return if (allow) AllowOrDeny.ALLOW else AllowOrDeny.DENY
        val cls = Class.forName("org.mozilla.geckoview.WebExtension\$PermissionPromptResponse")
        val ctor = cls.constructors.maxByOrNull { it.parameterTypes.size }!!
        val values = Array<Any?>(ctor.parameterTypes.size) { i -> if (i == 1) false else allow }
        return ctor.newInstance(*values)
    }

    private fun showInstallDialog() {
        val input = EditText(this).apply {
            hint = "addons.mozilla.org link or .xpi link"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
            try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip?.getItemAt(0)?.text?.toString()?.trim()
                if (clip != null && clip.startsWith("http")) setText(clip)
            } catch (_: Exception) {
            }
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Add extension")
            .setView(box)
            .setPositiveButton("Install") { _, _ -> installFromLink(input.text.toString()) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun resolveExtensionUrl(raw: String): String? {
        val s = raw.trim()
        val uri = Uri.parse(s)
        if (uri.scheme != "https" && uri.scheme != "http") return null
        val host = uri.host ?: return null
        if (host.endsWith("addons.mozilla.org")) {
            val segs = uri.pathSegments
            val i = segs.indexOf("addon")
            if (i >= 0 && i + 1 < segs.size) {
                return "https://addons.mozilla.org/firefox/downloads/latest/" +
                        Uri.encode(segs[i + 1]) + "/latest.xpi"
            }
        }
        return s // direct .xpi link
    }

    private fun installFromLink(raw: String) {
        val url = resolveExtensionUrl(raw)
        if (url == null) {
            toast("Please paste a valid extension link")
            return
        }
        toast("Installing\u2026")
        rt.webExtensionController.install(url).accept(
            { ext -> toast("Installed: " + (ext?.metaData?.name ?: "extension")) },
            { e -> toast("Install failed: " + (e?.message ?: "unknown error")) }
        )
    }

    private fun showExtensions() {
        rt.webExtensionController.list().accept(
            { list ->
                val exts = list ?: emptyList()
                if (exts.isEmpty()) {
                    toast("No extensions installed")
                } else {
                    val names = exts.map { it.metaData?.name ?: it.id }.toTypedArray()
                    AlertDialog.Builder(this)
                        .setTitle("Installed extensions (tap to remove)")
                        .setItems(names) { _, i -> confirmRemove(exts[i]) }
                        .setNegativeButton("Close", null)
                        .show()
                }
            },
            { e -> toast("Could not load extensions: " + (e?.message ?: "")) }
        )
    }

    private fun confirmRemove(ext: WebExtension) {
        val name = ext.metaData?.name ?: ext.id
        AlertDialog.Builder(this)
            .setTitle("Remove $name?")
            .setPositiveButton("Remove") { _, _ ->
                rt.webExtensionController.uninstall(ext).accept(
                    { toast("Removed") },
                    { e -> toast("Failed: " + (e?.message ?: "")) }
                )
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        session.close()
        super.onDestroy()
    }
}
